const IncomingForm = require("formidable").IncomingForm;
const fs = require('fs');
let exec = require("child_process").exec;

module.exports = function upload(req, res) {
  var form = new IncomingForm();

  form.on("file", (field, file) => {
    // Do something with the file
    // e.g. save it to the database
    // you can access it using file.path
    console.log('file saved at: ', file.path);
    const outputFile = `${file.path}.c`;
    const cmd = `move ${file.path} ${outputFile}`;

    let child = exec(cmd, function(execError, stdout, stderr) {
      console.log("stdout:" + stdout);
      console.log("stderr:" + stderr);

      if (execError !== null) {
        console.log("exec error: " + execError);
      }

      output = {
        stdout,
        stderr,
        execError
      };

      console.log("output object: ", output);

      // const filedata = fs.readFileSync("fileName");

      // res.status(200).json(output);
      res.sendFile(outputFile, error => {
        if (error) {
          console.log('Error during file send: ', error);
        } else {
          console.log(`File ${outputFile} successfully sent`);
        }
      });
    });
  });

  form.on("end", () => {
    // res.json();
  });

  form.parse(req);
};
