import React, { Component } from "react";
import "./App.css";
import Upload from "./upload/Upload";
import OutputCode from './OutputCode';

class App extends Component {
  state = {
    outputCodeText: ''
  }

  handleResponse = response => {
    this.setState({
      outputCodeText: response.outputCodeText
    })
  }

  render() {
    return (
      <div className="App">
        <div className="Card">
          <Upload />
        </div>
      </div>
    );
  }
}

export default App;
