# Sending Emails using node.js and Sendgrid

### Ready to use working project by nodejsera 
### Only Add your sendgrid API key and email and you are good to go.
